package com.ssafy.pjt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsafitDj3KimDongHyukParkByeongHoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsafitDj3KimDongHyukParkByeongHoApplication.class, args);
	}

}
