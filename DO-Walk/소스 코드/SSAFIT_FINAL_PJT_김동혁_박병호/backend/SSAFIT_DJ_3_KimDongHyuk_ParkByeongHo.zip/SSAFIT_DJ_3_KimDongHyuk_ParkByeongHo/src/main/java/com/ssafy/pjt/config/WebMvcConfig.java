package com.ssafy.pjt.config;

import com.ssafy.pjt.interceptor.loginInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new loginInterceptor())
                .addPathPatterns("/video/**")           // 보호할 경로
                .excludePathPatterns("/user/**", "/css/**", "/js/**", "/images/**"); // 허용 경로
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 정적 리소스 설정 (선택)
        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/static/");
    }
}
