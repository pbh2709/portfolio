package com.ssafy.pjt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.pjt.model.dto.Review;
import com.ssafy.pjt.model.service.ReviewService;

import jakarta.servlet.http.HttpSession;



@Controller
@RequestMapping("/review")
public class ReviewController {

	private final ReviewService reviewService;

	@Autowired
	public ReviewController(ReviewService reviewService) {
		this.reviewService = reviewService;
	}

	// 리뷰 등록 페이지로 이동
//	@GetMapping("/writeform")
//	public String writeform() {
//		return "videoRegist";
//	}

	@PostMapping("/write")
	public String writeForm(@RequestParam("videoNo") int videoNo, Model model, HttpSession session) {
	    model.addAttribute("loginUser", session.getAttribute("loginUser"));
	    return "reviewRegist";
	}
	
	@GetMapping("/list")
	public String list(Model model) {
	    List<Review> list = reviewService.getReviewList();
	    model.addAttribute("reviewList", list);
	    return "list"; 
	}

	@GetMapping("/detail")
	public String detail(@RequestParam("id") int id, Model model, HttpSession session) {
	    Review review = reviewService.readReview(id);
	    model.addAttribute("review", review);
	    model.addAttribute("loginUser", session.getAttribute("loginUser"));
	    return "reviewDetail"; 
	}

	// 수정 폼 이동
	@GetMapping("/updateform")
	public String updateForm(@RequestParam("id") int id, Model model) {
	    Review review = reviewService.readReview(id);
	    model.addAttribute("review", review);
	    return "reviewUpdate"; // 수정 페이지
	}

	// 수정 로직
	@PostMapping("/update")
	public String update(@ModelAttribute Review review) {
	    reviewService.modifyReview(review);
	    return "redirect:detail?id=" + review.getReviewNo(); // 다시 상세 페이지로
	}

	// 삭제 로직
	@GetMapping("/delete")
	public String delete(@RequestParam("id") int id, @RequestParam("videoNo") int videoNo) {
	    reviewService.removeReview(id);
	    return "redirect:detail/" + videoNo; // 비디오 상세로
	}


}
