package com.ssafy.pjt.controller;

import com.ssafy.pjt.model.dto.User;
import com.ssafy.pjt.model.service.userService;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
public class userController {

    @Autowired
    private userService userService;

    // ✅ 로그인 폼
    @GetMapping("/login")
    public String loginForm() {
        return "/login"; // /WEB-INF/views/user/userLogin.jsp
    }

    // ✅ 로그인 처리
    @PostMapping("/login")
    public String doLogin(User user, HttpSession session) {
        User loginUser = userService.login(user.getUserId(), user.getPassword());

        if (loginUser != null) {
            session.setAttribute("loginUser", loginUser);
            return "redirect:/video/list"; // 로그인 성공 시 비디오 목록으로
        } else {
            session.setAttribute("msg", "로그인 실패: 아이디 또는 비밀번호를 확인하세요.");
            return "redirect:login";
        }
    }

    // ✅ 로그아웃
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:login";
    }

    // ✅ 회원가입 폼
    @GetMapping("/form")
    public String registForm() {
        return "/userRegist"; // /WEB-INF/views/user/userRegist.jsp
    }

    // ✅ 회원가입 처리
    @PostMapping("/regist")
    public String regist(User user) {
        userService.insert(user);
        return "redirect:login";
    }

    // ✅ 마이페이지 (상세보기)
    @GetMapping("/mypage")
    public String mypage(HttpSession session, Model model) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null) return "redirect:/login";

        model.addAttribute("user", loginUser);
        return "/userDetail"; // /WEB-INF/views/user/userDetail.jsp
    }

    // ✅ 회원정보 수정 폼
    @GetMapping("/updateForm")
    public String updateForm(HttpSession session, Model model) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null) return "redirect:/login";

        model.addAttribute("user", loginUser);
        return "/userUpdate"; // /WEB-INF/views/user/userUpdate.jsp
    }

    // ✅ 회원정보 수정 처리
    @PostMapping("/update")
    public String update(User user, HttpSession session) {
        userService.update(user);
        session.setAttribute("loginUser", user); // 세션 갱신
        return "redirect:mypage";
    }

    // ✅ 회원 탈퇴
    @GetMapping("/delete/{userId}")
    public String delete(@PathVariable String userId, HttpSession session) {
        userService.delete(userId);
        session.invalidate(); // 세션 제거
        return "redirect:login";
    }
}
