package com.ssafy.pjt.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.pjt.model.dto.Review;
import com.ssafy.pjt.model.dto.Video;
import com.ssafy.pjt.model.service.ReviewService;
import com.ssafy.pjt.model.service.VideoService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/video")
public class videoController {

    @Autowired
    private VideoService videoService;
    @Autowired
    private ReviewService reviewService;

    // 비디오 목록 페이지
    @GetMapping("/list")
    public String list(Model model, HttpSession session) {
        List<Video> videos = videoService.getAll();
        model.addAttribute("videos", videos);

        // 세션에 로그인 유저 정보가 있다면 JSP에서 보여지도록
        model.addAttribute("loginUser", session.getAttribute("loginUser"));

        return "videoList"; // /WEB-INF/views/video/videoList.jsp
    }

    // 비디오 등록 폼
    @GetMapping("/form")
    public String form(Model model) {
        return "videoRegist";  // 영상 등록 폼
    }

    // 영상 등록 처리
    @PostMapping("/save")
    public String save(@ModelAttribute Video video) {
        videoService.insert(video);  // 새 영상 등록
        return "redirect:/video/list";  // 등록 후 영상 목록 페이지로 이동
    }

    // 영상 수정 페이지로 이동
    @GetMapping("/update/{videoNo}")
    public String videoUpdateForm(@PathVariable int videoNo, Model model) {
        Video video = videoService.getById(videoNo);
        model.addAttribute("video", video);
        return "videoUpdate";  // 영상 수정 폼
    }

    // 영상 수정 처리
    @PostMapping("/update")
    public String update(@ModelAttribute Video video) {
        videoService.update(video);
        return "redirect:/video/detail/" + video.getVideoNo();  // 수정 후 상세 페이지로 이동
    }
    
    
    @GetMapping("/detail/{videoNo}")
    public String detail(@PathVariable int videoNo, Model model, HttpSession session) {
        // 영상 정보
        model.addAttribute("video", videoService.getById(videoNo));

        // 리뷰 목록 추가
        List<Review> reviewList = reviewService.getReviewsByVideoNo(videoNo);
        model.addAttribute("reviewList", reviewList);

        // 로그인 유저 정보
        model.addAttribute("loginUser", session.getAttribute("loginUser"));

        return "videoDetail"; // /WEB-INF/views/videoDetail.jsp
    }

    // 삭제
    @GetMapping("/delete/{videoNo}")
    public String delete(@PathVariable int videoNo) {
        videoService.delete(videoNo);
        return "redirect:/list";
    }

    // 검색
    @GetMapping("/search")
    public String search(@RequestParam String keyword, Model model) {
        List<Video> result = videoService.search(keyword);
        model.addAttribute("videos", result);
        return "videoList";
    }
}
