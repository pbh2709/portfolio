package com.ssafy.pjt.model.dto;

import java.util.Date;

public class Video {
    private int videoNo;
    private String videoTitle;
    private String channelName;
    private int viewCount;
    private Date uploadDate;
    private byte videoLike;
    private String field;
    private int fitnessPartNo;

    public Video() {}

    public Video(int videoNo, String videoTitle, String channelName, int viewCount,
                 Date uploadDate, byte videoLike, String field, int fitnessPartNo) {
        this.videoNo = videoNo;
        this.videoTitle = videoTitle;
        this.channelName = channelName;
        this.viewCount = viewCount;
        this.uploadDate = uploadDate;
        this.videoLike = videoLike;
        this.field = field;
        this.fitnessPartNo = fitnessPartNo;
    }

    public int getVideoNo() {
        return videoNo;
    }

    public void setVideoNo(int videoNo) {
        this.videoNo = videoNo;
    }

    public String getVideoTitle() {
        return videoTitle;
    }

    public void setVideoTitle(String videoTitle) {
        this.videoTitle = videoTitle;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public int getViewCount() {
        return viewCount;
    }

    public void setViewCount(int viewCount) {
        this.viewCount = viewCount;
    }

    public Date getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(Date uploadDate) {
        this.uploadDate = uploadDate;
    }

    public byte getVideoLike() {
        return videoLike;
    }

    public void setVideoLike(byte videoLike) {
        this.videoLike = videoLike;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public int getFitnessPartNo() {
        return fitnessPartNo;
    }

    public void setFitnessPartNo(int fitnessPartNo) {
        this.fitnessPartNo = fitnessPartNo;
    }
}
