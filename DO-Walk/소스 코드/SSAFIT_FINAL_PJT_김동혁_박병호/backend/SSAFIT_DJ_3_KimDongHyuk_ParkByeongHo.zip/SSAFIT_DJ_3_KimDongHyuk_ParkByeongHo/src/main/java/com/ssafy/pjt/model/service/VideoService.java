package com.ssafy.pjt.model.service;

import java.util.List;
import com.ssafy.pjt.model.dto.Video;

public interface VideoService {
    List<Video> getAll();
    Video getById(int videoNo);
    boolean insert(Video video);
    boolean update(Video video);
    boolean delete(int videoNo);
    List<Video> search(String keyword);
}