package com.ssafy.pjt.model.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ssafy.pjt.model.dao.VideoDao;
import com.ssafy.pjt.model.dto.Video;

@Service
public class VideoServiceImpl implements VideoService {

    @Autowired
    private VideoDao videoDao;

    @Override
    public List<Video> getAll() {
        return videoDao.selectAll();
    }

    @Override
    public Video getById(int videoNo) {
        return videoDao.selectById(videoNo);
    }

    @Override
    public boolean insert(Video video) {
        return videoDao.insert(video) > 0;
    }

    @Override
    public boolean update(Video video) {
        return videoDao.update(video) > 0;
    }

    @Override
    public boolean delete(int videoNo) {
        return videoDao.delete(videoNo) > 0;
    }

    @Override
    public List<Video> search(String keyword) {
        return videoDao.searchByTitle(keyword);
    }
}