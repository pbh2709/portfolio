package com.ssafy.pjt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsafitDj3KimDongHyukParkByeongHoApplicationTests {

	@Test
	void contextLoads() {
	}

}
